# Rent House Direct
A simple platform to connect Nigerian tenants and landlords directly.